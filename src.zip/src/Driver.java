/**
 * Created by Tom on 2/25/15.
 */
public class Driver {
    String name;
    public Driver(){
        name = " ";
    }

    public Driver(String name){
        this.name = name;
    }

    //getters and setters
    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }
}
